﻿App.service("commonService", ["$http", function ($http) {
   
}]);